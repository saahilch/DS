package Q2;

public class Tester {

	public static void main(String[] args) {
		Student s1=new Student(1, "omkar", 10);
		Student s2=new Student(2, "sahil", 20);
		Student s3=new Student(3, "panda", 30);
		Student s4=new Student(4, "amar", 40);
		Stack stack=new Stack(4);
		stack.display();
		System.out.println(stack.isEmpty());
		stack.push(s1);
		stack.push(s2);
		stack.push(s3);
		stack.push(s4);
		System.out.println("fullllll");
		System.out.println(stack.isFull());
		stack.display();
		System.out.println(stack.pop());
		stack.display();
		System.out.println(stack.peek());
		stack.display();
	}

}
