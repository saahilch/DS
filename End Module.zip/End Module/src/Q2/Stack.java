package Q2;

public class Stack {
	private int top;
	private Student[]arr;
	private int size;
	public Stack(int size) {
		super();
		this.size = size;
		this.top=-1;
		this.arr=new Student[size];
	}
	
	public boolean isEmpty() {
		return top==-1;
	}
	
	public boolean isFull() {
		return top==size-1;
	}
	
	public boolean push(Student s1) {
		if(isFull()) {
			return false;
		}
		arr[++top]=s1;
		return true;
	}
	
	public Student pop() {
		if(isEmpty()) {
			return null;
		}
		Student s1=arr[top];
		arr[top--]=null;
		return s1;
	}
	
	public Student peek() {
		if(isEmpty()) {
			return null;
		}
		return arr[top];
	}
	
	public void display() {
		for(int i=arr.length-1;i>=0;i--) {
			System.out.println(arr[i]+" ");
		}
		System.out.println();
	}

}
