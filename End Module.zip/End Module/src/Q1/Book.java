package Q1;

public class Book {
	private int bookId;
	private String BookTitle;
	private String BookAuthor;
	private double price;
	public Book(int bookId, String bookTitle, String bookAuthor, double price) {
		super();
		this.bookId = bookId;
		BookTitle = bookTitle;
		BookAuthor = bookAuthor;
		this.price = price;
	}
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getBookTitle() {
		return BookTitle;
	}
	public void setBookTitle(String bookTitle) {
		BookTitle = bookTitle;
	}
	public String getBookAuthor() {
		return BookAuthor;
	}
	public void setBookAuthor(String bookAuthor) {
		BookAuthor = bookAuthor;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", BookTitle=" + BookTitle + ", BookAuthor=" + BookAuthor + ", price=" + price
				+ "]";
	}
	
	
}
