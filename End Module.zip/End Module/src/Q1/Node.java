package Q1;

public class Node {
	Book book;
	Node next;
	
	public Node(Book book) {
		super();
		this.book = book;
		this.next=null;
	}

	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}

	public Node getNext() {
		return next;
	}

	public void setNext(Node next) {
		this.next = next;
	}
	
	
}
