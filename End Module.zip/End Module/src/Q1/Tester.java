package Q1;

import java.util.Scanner;

public class Tester {

	public static void main(String[] args) {
		Book b1=new Book(1, "aaa", "omkar", 100);
		Book b2=new Book(2, "bbb", "sahil", 200);
		Book b3=new Book(3, "ccc", "panda", 300);
		
		SinglyLinkedList s1=new SinglyLinkedList();
		Scanner sc=new Scanner(System.in);
		int ch;
		System.out.println("Enter the choice");
		ch=sc.nextInt();
		
		
		s1.insertAtFront(b1);
		s1.insertAtLast(b2);
		s1.insertByPosition(b3, 2);
		s1.display();
		s1.countNoOfNode();
		s1.deleteAtFront();
		s1.deleteAtEnd();
		s1.searchByTitle("bbb");
		s1.deleteByPosition(2);
		s1.display();
		s1.countNoOfNode();
		
	}

}
