package Q1;

import java.util.Iterator;

public class SinglyLinkedList {
	private Node head;
	private int count=0;
	
	public SinglyLinkedList() {
		head=null;
	}
	
	public void display() {
		Node temp=head;
		while(temp!=null) {
			System.out.println(temp.getBook()+" ");
			temp=temp.getNext();
		}
		System.out.println();
	}
	
	public void countNoOfNode() {
		System.out.println("count="+count);
	}
	
	public boolean insertAtFront(Book b1) {
		Node newNode=new Node(b1);
		if (head==null) {
			head=newNode;
			count+=1;
			return true;
		}
		newNode.setNext(head);
		head=newNode;
		count+=1;
		return true;
	}
	
	public boolean insertAtLast(Book b1) {
		Node newNode=new Node(b1);
		if(head==null) {
			head=newNode;
			count+=1;
			return true;
		}
		Node temp=head;
		while(temp.getNext()!=null) {
			temp=temp.getNext();
		}
		temp.setNext(newNode);
		count+=1;
		return true;
	}
	
	public boolean insertByPosition(Book b1,int position) {
		Node newNode=new Node(b1);
		if(head==null&&position!=1) {
			return false;
		}
		if(position==1) {
			if(head==null) {
				head=newNode;
				count+=1;
				return true;
			}
			newNode.setNext(head);
			head=newNode;
			count+=1;
			return true;
		}
		if(position>1) {
			Node temp=head;
			for(int i=1;i<position-1;i++) {
				temp=temp.getNext();
			}
			newNode.setNext(temp.getNext());
			temp.setNext(newNode);
			count+=1;
			return true;
		}
		
		return false;
	}
	
	public boolean deleteAtFront() {
		if(head==null) {
			return false;
		}
		head=head.getNext();
		count-=1;
		return true;
	}
	
	public boolean deleteAtEnd() {
		if(head==null) {
			return false;
		}
		if(head.getNext()==null) {
			head=null;
			count-=1;
			return true;
		}
		Node del=head;
		Node prev=head;
		while(del.getNext()!=null) {
			prev=del;
			del=del.getNext();
		}
		prev.setNext(del.getNext());
		count-=1;
		return true;	
	}
	
	public boolean deleteByPosition(int position) {
		if(head==null) {
			return false;
		}
		if(position==1) {
			head=head.getNext();
			count-=1;
			return true;
		}
		if(position>1) {
			Node del=head;
			Node prev=head;
			for(int i=1;i<position;i++) {
				prev=del;
				del=del.getNext();
			}
			prev.setNext(del.getNext());
			count-=1;
			return true;
		}
		return false;
	}
	
	public void searchByTitle(String title) {
		Node temp=head;
		for(int i=1;i<=count;i++) {
			if(title.equals(temp.getBook().getBookTitle())) {
				System.out.println(temp.getBook());
				return;
			}
			temp=temp.getNext();
		}
		System.out.println("book not found");
	}

}
